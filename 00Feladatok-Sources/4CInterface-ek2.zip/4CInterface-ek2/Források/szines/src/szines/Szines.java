package szines;

/**
 * SzinesPont alkalmazása
 * @author Tóth József
 */
public class Szines {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }
}

