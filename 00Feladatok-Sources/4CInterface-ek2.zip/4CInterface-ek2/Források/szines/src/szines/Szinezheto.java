package szines;
import javafx.scene.paint.Color;

/**
 * színezhető interface
 *
 * @author Tóth József
 */
public interface Szinezheto {
    public abstract Color getSzin();
    public abstract void setSzin(Color szin);
    
    public static final Color ALAPSZIN = Color.GREEN;
}
