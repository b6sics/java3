package alkalmazottDemo;
/**
 * Alkalmazott osztály kipróbálása
 * @author Tóth József
 */
public class AlkalmazottDemo {

    public static void main(String[] args) {
        Alkalmazott a = new Alkalmazott("Nagy János",300000);
        System.out.println(a.adatok());
        a.novel(10000);
        System.out.println(a.adatok());
    }
}
