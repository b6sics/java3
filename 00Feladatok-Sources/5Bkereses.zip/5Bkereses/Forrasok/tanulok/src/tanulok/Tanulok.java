package tanulok;

import java.util.ArrayList;
import java.util.Collections;

public class Tanulok {

    private static ArrayList<Tanulo> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        lista.add(new Tanulo("Kis János", 2000, 3.22));
        lista.add(new Tanulo("Nagy László", 2002, 2.11));
        lista.add(new Tanulo("Szabó Géza", 2001, 3.44));
        lista.add(new Tanulo("Kovács Éva", 1998, 4.33));
        lista.add(new Tanulo("Tóth János", 1999, 4.01));
        lista.add(new Tanulo("Kovács Éva", 2000, 2.55));
        lista.add(new Tanulo("Varga Judit", 1996, 4.56));
        lista.add(new Tanulo("Simon Lajos", 2003, 3.67));
        
        // lineáris keresés
        
        // lista másolása
        
        // másolat rendezése név szerint
        
        // bináris keresés

    }
}
   
